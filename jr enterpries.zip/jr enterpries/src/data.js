export const data = [
  {images:[
    {img:'./clear.webp'},
    {img:'./bisk1.webp'},
    {img:"./bailry.webp"}
  ]},
    {
      deliveryOptions:[
        {
          id: 1,
          company: "Bisleri",
          quantity: "20 Litres",
          price: "₹120",
          image: "water_bottle_image.jpg"
        },
        {
          id: 2,
          company: "Swarganga Bisleri",
          quantity: "20 Litres",
          price: "₹120",
          image: "water_bottle_image.jpg"
        },
        {
          id: 3,
          company: "Swarganga",
          quantity: "20 Litres",
          price: "₹50",
          image: "water_bottle_image.jpg"
        }
      ]
    }
]  ;
  