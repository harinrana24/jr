
import './App.css'
import Home from './Home'
import { HashRouter as Router, Route, Routes } from 'react-router-dom';
import AboutUs from './Pages/About';
import Services from './Pages/Services';


function App() {
 

  return (
    <>
      <Router>
         <Routes>
               <Route path="/" element={<Home/>} />
               <Route path="/about" element={<AboutUs/>} />
               <Route path="/services" element={<Services/>} />
          </Routes>
      </Router>
    </>
  )
}

export default App
