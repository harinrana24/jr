import React from 'react';
import NavigationBar from '../components/Navbar';

const AboutUs = () => {
  return (<>
  <NavigationBar/>
    <div className="About about-us-container">
      <div className="about-us-content">
        <h1>About JR Enterprises</h1>
        <p>
          Welcome to JR Enterprises, your trusted partner in the beverage industry for over 25 years.
          Since [year of foundation], we have been dedicated to delivering top-quality products and
          exceptional service to our customers.
        </p>
        <p>
          At JR Enterprises, we take pride in our extensive range of offerings. From our flagship
          packaged water to a diverse selection of soft drinks, juices, and energy drinks, we cater
          to every taste and preference. Our commitment to quality extends to our water accessories
          as well, including water pumps, filtration systems, and hydration solutions.
        </p>
        <p>
          Our journey began [25 years ago], with a vision to provide refreshing and healthy beverages
          to consumers across the nation. Over the years, we have expanded our operations, forged
          strategic partnerships, and built a network of distributors that spans over Mumbai.
          Today, JR Enterprises is synonymous with reliability, quality, and innovation.
        </p>
        <p>
          What sets us apart is our unwavering commitment to excellence. From the sourcing of
          premium ingredients to the packaging and distribution of our products, we adhere to the
          highest standards of quality and safety. Our state-of-the-art facilities and stringent
          quality control measures ensure that every product that bears the JR Enterprises name
          meets our rigorous standards.
        </p>
        <p>
          Our success wouldn't be possible without the dedication and hard work of our team. We are
          proud of our talented employees who bring passion, creativity, and expertise to everything
          they do. Together, we continue to push the boundaries of innovation and strive for
          continuous improvement.
        </p>
        <p>
          As we look to the future, our commitment to our customers and our values remains steadfast.
          We will continue to innovate, to adapt, and to deliver products that enrich the lives of
          our consumers. Thank you for choosing JR Enterprises - we look forward to serving you for
          many more years to come.
        </p>
      </div>
    </div></>
  );
};

export default AboutUs;
