import React, { useEffect, useState } from 'react';

const Services = () => {
  const [deliveryOptions, setDeliveryOptions] = useState([]);

  useEffect(() => {
    fetch('/services.json')
      .then(response => response.json())
      .then(data => setDeliveryOptions(data))
      .catch(error => console.error('Error fetching delivery options:', error));
  }, []);

  return (
    <div className="services-container">
      <div className="services-content">
        <h1>Our Delivery Services</h1>
        <div className="delivery-options">
          {deliveryOptions.map(option => (
            <div className="delivery-option" key={option.id}>
              <img src={option.image} alt="Water Bottle" className="delivery-image" />
              <div className="delivery-details">
                <h2>{option.company}</h2>
                <p>{option.quantity}</p>
                <p>Price: {option.price}</p>
              </div>
            </div>
          ))}
        </div>
        <p className="delivery-info">We deliver online throughout Virar. Contact us for more information.</p>
      </div>
    </div>
  );
};

export default Services;
