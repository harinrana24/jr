import React from 'react';

const Watermark = () => {
  return (
    <section id='watermark' >
        <div className="watermark">
          <div className="content">
             <img src="./isi.png" alt="ISI Certified Logo" className="logo" />
             <div className="text-container">
          <p className="heading">Quality You Can Trust</p>
          <p className="text">
            JR Enterprises is dedicated to providing you with water that not only quenches your
            thirst but also exceeds your expectations. Our water is sourced from the purest
            natural springs and undergoes stringent filtration and purification processes to ensure
            its pristine quality. Each drop is infused with the essence of purity and carries the
            assurance of safety. With our ISI certification, you can rest assured that every glass
            you drink is free from impurities and contaminants, making it not just water, but a
            symbol of trust and well-being.
          </p>
          <p className="text">
            Our commitment to excellence extends beyond quality. We believe in transparency,
            sustainability, and customer satisfaction. From our environmentally-friendly
            manufacturing processes to our prompt and reliable customer service, we strive to
            exceed your expectations at every step. When you choose JR Enterprises, you're not just
            choosing water; you're choosing a partner in your journey towards a healthier and
            happier life.
          </p>
          <p className="benefits">
            Experience the JR Enterprises difference today!
          </p>
          <p className="contact">Contact us now to elevate your water experience!</p>
        </div>
      </div>
    </div>
   </section>
  );
};

export default Watermark;
