import React, { useState, useEffect } from 'react';
import { data } from '../data.js'; 

const Carousel = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentImageIndex((prevIndex) =>
        prevIndex === data[0].images.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000);

    return () => clearInterval(intervalId);
  }, []);

  return (
    <section>
      <div className="carousel">
        <img src={data[0].images[currentImageIndex].img} alt={`Image ${currentImageIndex}`} />
      </div>
    </section>
  );
};

export default Carousel;
