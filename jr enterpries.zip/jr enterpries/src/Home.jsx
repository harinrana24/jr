import React from 'react'
import NavigationBar from './components/Navbar'
import Carousel from './components/Carosel'
import Watermark from './components/Watermar'

const Home = () => {
  return (
    <div>
        <NavigationBar/>
        <Carousel/>
        <Watermark/>
    </div>
  )
}

export default Home